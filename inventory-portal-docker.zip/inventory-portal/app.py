"""Office inventory portal - start file.

Run for testing:   python app.py
Run for real use:  run.bat   (uses waitress)
"""
import secrets
from datetime import timedelta

from flask import Flask, abort, g, redirect, render_template, request, session, url_for

import config
import models
from auth import bp as auth_bp
from models import get_db
from routes_admin import bp as admin_bp
from routes_user import bp as user_bp


def create_app():
    app = Flask(__name__)
    app.config.update(
        SECRET_KEY=config.get_secret_key(),
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=config.HTTPS_ONLY,
        PERMANENT_SESSION_LIFETIME=timedelta(hours=config.SESSION_HOURS),
        MAX_CONTENT_LENGTH=1024 * 1024,   # uploads up to 1 MB
    )
    models.init_db()
    models.init_app(app)

    app.register_blueprint(auth_bp)
    app.register_blueprint(user_bp)
    app.register_blueprint(admin_bp)

    @app.before_request
    def load_user_and_check_csrf():
        g.user = None
        user_id = session.get("user_id")
        if user_id:
            row = get_db().execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
            if row is not None and row["is_active"]:
                g.user = row
            else:
                session.clear()

        if request.method == "POST":
            token = session.get("csrf") or ""
            sent = request.form.get("csrf_token") or ""
            if not token or not secrets.compare_digest(token, sent):
                abort(400)

        if (g.user is not None and g.user["must_change_password"]
                and request.endpoint not in ("auth.change_password", "auth.logout", "static")):
            return redirect(url_for("auth.change_password"))

    @app.context_processor
    def inject_csrf():
        def csrf_token():
            if "csrf" not in session:
                session["csrf"] = secrets.token_hex(16)
            return session["csrf"]
        return {"csrf_token": csrf_token}

    @app.after_request
    def security_headers(resp):
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["Referrer-Policy"] = "same-origin"
        resp.headers["Cache-Control"] = "no-store"
        return resp

    @app.errorhandler(400)
    def bad_request(_e):
        return render_template("error.html", code=400,
                               message="This page has expired. Go back, refresh it and try again."), 400

    @app.errorhandler(403)
    def forbidden(_e):
        return render_template("error.html", code=403,
                               message="You do not have permission to open this page."), 403

    @app.errorhandler(404)
    def not_found(_e):
        return render_template("error.html", code=404, message="This page was not found."), 404

    @app.errorhandler(413)
    def too_large(_e):
        return render_template("error.html", code=413, message="The file is too large (limit 1 MB)."), 413

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8000, debug=False)
