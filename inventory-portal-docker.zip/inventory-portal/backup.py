"""Make a safe copy of portal.db into the backups folder (keeps the newest 30)."""
import glob
import os
import sqlite3
from datetime import datetime

import config

backup_dir = os.path.join(config.DATA_DIR, "backups")
os.makedirs(backup_dir, exist_ok=True)
target = os.path.join(backup_dir, "portal_" + datetime.now().strftime("%Y%m%d_%H%M") + ".db")

src = sqlite3.connect(config.DB_PATH)
dst = sqlite3.connect(target)
with dst:
    src.backup(dst)      # safe even while the portal is running
dst.close()
src.close()

for old in sorted(glob.glob(os.path.join(backup_dir, "portal_*.db")))[:-30]:
    os.remove(old)
print("Backup saved:", target)
