#!/bin/sh
# Makes a safe backup of the portal database and copies all backups to ./backups-copy
cd "$(dirname "$0")" || exit 1
docker compose exec -T portal python backup.py || exit 1
mkdir -p backups-copy
docker compose cp portal:/data/backups/. ./backups-copy/
echo "Backups are in $(pwd)/backups-copy"
