"""Small helpers shared by the pages."""
import csv
import io
import re
import secrets
from datetime import date, datetime

from flask import Response

# (database column, label shown on screen and in the CSV file)
EQUIPMENT_FIELDS = [
    ("asset_tag", "Asset tag"),
    ("name", "Equipment name"),
    ("type", "Type"),
    ("brand", "Brand"),
    ("model", "Model"),
    ("serial_no", "Serial no"),
    ("location", "Location"),
    ("status", "Status"),
    ("purchase_date", "Purchase date"),
    ("remarks", "Remarks"),
]

STATUS_CHOICES = ["In use", "In stock", "Under repair", "Damaged", "Retired"]
TYPE_SUGGESTIONS = ["Desktop", "Laptop", "Monitor", "Printer", "Scanner", "Router",
                    "Switch", "Access point", "UPS", "Phone", "Tablet", "Projector",
                    "Server", "Keyboard", "Mouse", "Other"]

EQUIPMENT_SELECT = """
    SELECT e.*, u.full_name AS owner_name, u.username AS owner_username,
           d.name AS department_name
    FROM equipment e
    JOIN users u ON u.id = e.owner_id
    LEFT JOIN departments d ON d.id = e.department_id
"""

_PASSWORD_CHARS = "abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789"


def generate_password(length=10):
    return "".join(secrets.choice(_PASSWORD_CHARS) for _ in range(length))


def parse_equipment(form):
    """Read the equipment form. Every field is optional (blank is allowed).

    Returns (data, error). Only a completely empty form is refused.
    """
    data = {}
    for col, _label in EQUIPMENT_FIELDS:
        value = (form.get(col) or "").strip()
        limit = 2000 if col == "remarks" else 200
        data[col] = value[:limit] if value else None

    if data["purchase_date"]:
        try:
            datetime.strptime(data["purchase_date"], "%Y-%m-%d")
        except ValueError:
            return data, "Purchase date must look like 2026-10-26."

    if not any(data.values()):
        return data, "Fill in at least one field before saving."
    return data, None


def search_clause(q):
    """SQL for a simple search over all equipment columns."""
    if not q:
        return "", []
    like = "%" + q.replace("\\", "\\\\").replace("%", r"\%").replace("_", r"\_") + "%"
    cols = [c for c, _ in EQUIPMENT_FIELDS]
    sql = " AND (" + " OR ".join(f"e.{c} LIKE ? ESCAPE '\\'" for c in cols) + ")"
    return sql, [like] * len(cols)


def _safe_cell(value):
    """Stop Excel from running a cell that starts with = + - @ (CSV injection)."""
    if value is None:
        return ""
    text = str(value)
    if text and text[0] in "=+-@\t\r":
        return "'" + text
    return text


def csv_response(rows, filename_prefix, include_owner=False):
    """Build a CSV download (opens correctly in Excel, ready to print)."""
    out = io.StringIO()
    writer = csv.writer(out)
    header = [label for _c, label in EQUIPMENT_FIELDS]
    if include_owner:
        header += ["Owner", "Username", "Department"]
    writer.writerow(header)
    for r in rows:
        line = [_safe_cell(r[c]) for c, _l in EQUIPMENT_FIELDS]
        if include_owner:
            line += [_safe_cell(r["owner_name"]), _safe_cell(r["owner_username"]),
                     _safe_cell(r["department_name"])]
        writer.writerow(line)
    name = re.sub(r"[^A-Za-z0-9_-]+", "_", filename_prefix).strip("_") or "inventory"
    filename = f"{name}_{date.today().isoformat()}.csv"
    resp = Response("\ufeff" + out.getvalue(), mimetype="text/csv")
    resp.headers["Content-Type"] = "text/csv; charset=utf-8"
    resp.headers["Content-Disposition"] = f'attachment; filename="{filename}"'
    return resp
