"""Admin pages: users, departments, all equipment, import, activity log."""
import csv
import io
import sqlite3

from flask import (Blueprint, abort, flash, g, redirect, render_template, request,
                   url_for)
from werkzeug.security import generate_password_hash

from auth import admin_required
from import_users import import_users
from models import get_db, log
from utils import (EQUIPMENT_SELECT, csv_response, generate_password, search_clause)

bp = Blueprint("admin", __name__, url_prefix="/admin")


def _departments():
    return get_db().execute("SELECT id, name FROM departments ORDER BY name").fetchall()


# ---------------------------------------------------------------- users
@bp.route("/users")
@admin_required
def users():
    q = (request.args.get("q") or "").strip()
    sql = ("SELECT u.*, d.name AS department_name, "
           "(SELECT COUNT(*) FROM equipment e WHERE e.owner_id = u.id) AS item_count "
           "FROM users u LEFT JOIN departments d ON d.id = u.department_id")
    params = []
    if q:
        like = "%" + q.replace("%", r"\%").replace("_", r"\_") + "%"
        sql += (" WHERE u.full_name LIKE ? ESCAPE '\\' OR u.username LIKE ? ESCAPE '\\'"
                " OR d.name LIKE ? ESCAPE '\\'")
        params = [like] * 3
    rows = get_db().execute(sql + " ORDER BY u.full_name", params).fetchall()
    return render_template("admin_users.html", rows=rows, q=q)


@bp.route("/users/add", methods=["GET", "POST"])
@admin_required
def user_add():
    departments = _departments()
    if not departments:
        flash("Add a department first.", "error")
        return redirect(url_for("admin.departments"))
    form = request.form if request.method == "POST" else {}
    if request.method == "POST":
        full_name = (form.get("full_name") or "").strip()
        username = (form.get("username") or "").strip()
        dept = form.get("department_id") or ""
        role = form.get("role") or "user"
        password = (form.get("password") or "").strip()
        db = get_db()
        error = None
        if not full_name or not username or not dept.isdigit():
            error = "Full name, username and department are required."
        elif role not in ("user", "admin"):
            error = "Role must be user or admin."
        elif password and len(password) < 8:
            error = "A password you type must have at least 8 characters."
        elif db.execute("SELECT 1 FROM users WHERE username = ?", (username,)).fetchone():
            error = f"The username '{username}' is already used."
        if error:
            flash(error, "error")
        else:
            password = password or generate_password()
            db.execute(
                "INSERT INTO users(full_name, username, password_hash, department_id, role,"
                " must_change_password) VALUES (?,?,?,?,?,1)",
                (full_name, username, generate_password_hash(password), int(dept), role))
            log(db, "user_add", username)
            db.commit()
            flash(f"User created. Temporary password for {username}: {password}", "secret")
            return redirect(url_for("admin.users"))
    return render_template("admin_user_form.html", item=form, departments=departments,
                           editing=False)


@bp.route("/users/<int:user_id>/edit", methods=["GET", "POST"])
@admin_required
def user_edit(user_id):
    db = get_db()
    row = db.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    if row is None:
        abort(404)
    departments = _departments()
    if request.method == "POST":
        full_name = (request.form.get("full_name") or "").strip()
        dept = request.form.get("department_id") or ""
        role = request.form.get("role") or "user"
        active = 1 if request.form.get("is_active") else 0
        error = None
        if not full_name or not dept.isdigit():
            error = "Full name and department are required."
        elif role not in ("user", "admin"):
            error = "Role must be user or admin."
        elif row["id"] == g.user["id"] and (role != "admin" or not active):
            error = "You cannot remove your own admin access or disable yourself."
        if error:
            flash(error, "error")
        else:
            db.execute("UPDATE users SET full_name=?, department_id=?, role=?, is_active=? "
                       "WHERE id=?", (full_name, int(dept), role, active, user_id))
            # keep each equipment record in the department of its owner
            db.execute("UPDATE equipment SET department_id=? WHERE owner_id=?",
                       (int(dept), user_id))
            log(db, "user_edit", row["username"])
            db.commit()
            flash("User updated.", "ok")
            return redirect(url_for("admin.users"))
    return render_template("admin_user_form.html", item=dict(row), departments=departments,
                           editing=True)


@bp.route("/users/<int:user_id>/reset", methods=["POST"])
@admin_required
def user_reset(user_id):
    db = get_db()
    row = db.execute("SELECT username FROM users WHERE id = ?", (user_id,)).fetchone()
    if row is None:
        abort(404)
    password = generate_password()
    db.execute("UPDATE users SET password_hash=?, must_change_password=1 WHERE id=?",
               (generate_password_hash(password), user_id))
    log(db, "password_reset", row["username"])
    db.commit()
    flash(f"New temporary password for {row['username']}: {password}", "secret")
    return redirect(url_for("admin.users"))


# ---------------------------------------------------------- departments
@bp.route("/departments", methods=["GET", "POST"])
@admin_required
def departments():
    db = get_db()
    if request.method == "POST":
        name = " ".join((request.form.get("name") or "").split())[:100]
        if not name:
            flash("Type the department name.", "error")
        else:
            try:
                db.execute("INSERT INTO departments(name) VALUES (?)", (name,))
                log(db, "department_add", name)
                db.commit()
                flash(f"Department '{name}' added.", "ok")
            except sqlite3.IntegrityError:
                flash(f"The department '{name}' already exists.", "error")
        return redirect(url_for("admin.departments"))
    rows = db.execute(
        "SELECT d.id, d.name, "
        "(SELECT COUNT(*) FROM users u WHERE u.department_id = d.id) AS user_count, "
        "(SELECT COUNT(*) FROM equipment e WHERE e.department_id = d.id) AS item_count "
        "FROM departments d ORDER BY d.name").fetchall()
    return render_template("admin_departments.html", rows=rows)


@bp.route("/departments/<int:dept_id>/delete", methods=["POST"])
@admin_required
def department_delete(dept_id):
    db = get_db()
    row = db.execute("SELECT name FROM departments WHERE id = ?", (dept_id,)).fetchone()
    if row is None:
        abort(404)
    users = db.execute("SELECT COUNT(*) FROM users WHERE department_id=?", (dept_id,)).fetchone()[0]
    items = db.execute("SELECT COUNT(*) FROM equipment WHERE department_id=?", (dept_id,)).fetchone()[0]
    if users or items:
        flash(f"'{row['name']}' still has {users} user(s) and {items} equipment record(s). "
              "Move the users to another department first.", "error")
    else:
        db.execute("DELETE FROM departments WHERE id = ?", (dept_id,))
        log(db, "department_delete", row["name"])
        db.commit()
        flash(f"Department '{row['name']}' removed.", "ok")
    return redirect(url_for("admin.departments"))


# ------------------------------------------------------ all equipment
def _filtered_equipment():
    q = (request.args.get("q") or "").strip()
    dept = request.args.get("department") or ""
    owner = request.args.get("owner") or ""
    sql, params = search_clause(q)
    where = " WHERE 1=1" + sql
    if dept.isdigit():
        where += " AND e.department_id = ?"
        params.append(int(dept))
    if owner.isdigit():
        where += " AND e.owner_id = ?"
        params.append(int(owner))
    rows = get_db().execute(
        EQUIPMENT_SELECT + where + " ORDER BY d.name, u.full_name, e.id", params).fetchall()
    return rows, q, dept, owner


@bp.route("/equipment")
@admin_required
def all_equipment():
    rows, q, dept, owner = _filtered_equipment()
    people = get_db().execute("SELECT id, full_name, username FROM users ORDER BY full_name").fetchall()
    return render_template("admin_all_equipment.html", rows=rows, q=q, dept=dept,
                           owner=owner, departments=_departments(), people=people)


@bp.route("/equipment/download")
@admin_required
def all_equipment_download():
    rows, _q, dept, _owner = _filtered_equipment()
    name = "all_inventory"
    if dept.isdigit():
        d = get_db().execute("SELECT name FROM departments WHERE id=?", (int(dept),)).fetchone()
        if d:
            name = "inventory_" + d["name"]
    log(get_db(), "download_csv", name)
    get_db().commit()
    return csv_response(rows, name, include_owner=True)


# ---------------------------------------------------------- import
@bp.route("/import", methods=["GET", "POST"])
@admin_required
def import_page():
    if request.method == "POST":
        file = request.files.get("file")
        if not file or not file.filename:
            flash("Choose a CSV file first.", "error")
            return render_template("admin_import.html")
        try:
            text = file.read().decode("utf-8-sig")
        except UnicodeDecodeError:
            flash("Save the file as CSV UTF-8 and try again.", "error")
            return render_template("admin_import.html")
        db = get_db()
        created, skipped = import_users(db, text)
        log(db, "user_import", f"{len(created)} created, {len(skipped)} skipped")
        db.commit()
        out = io.StringIO()
        writer = csv.writer(out)
        writer.writerow(["full_name", "username", "department", "role", "temporary_password"])
        for c in created:
            writer.writerow([c["full_name"], c["username"], c["department"], c["role"], c["password"]])
        return render_template("admin_import_result.html", created=created, skipped=skipped,
                               credentials_csv=out.getvalue())
    return render_template("admin_import.html")


# ------------------------------------------------------ activity log
@bp.route("/activity")
@admin_required
def activity():
    rows = get_db().execute(
        "SELECT * FROM activity_log ORDER BY id DESC LIMIT 300").fetchall()
    return render_template("admin_activity.html", rows=rows)
