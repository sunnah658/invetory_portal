"""Portal settings. Change values here if you need to."""
import os
import secrets

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Folder that holds the database, secret key and backups.
# In Docker this is the /data volume. Without Docker it is the project folder.
DATA_DIR = os.environ.get("PORTAL_DATA", BASE_DIR)
os.makedirs(DATA_DIR, exist_ok=True)

# Database file (keep it on a LOCAL disk of the server, not on a network share)
DB_PATH = os.environ.get("PORTAL_DB", os.path.join(DATA_DIR, "portal.db"))

# First admin account (created only once, on the very first start).
# The portal forces a password change at first login.
DEFAULT_ADMIN_USERNAME = "admin"
DEFAULT_ADMIN_PASSWORD = "ChangeMe@123"
DEFAULT_ADMIN_NAME = "Portal Admin"
DEFAULT_DEPARTMENT = "IT"

# Login stays valid for this many hours
SESSION_HOURS = 8

# Set environment variable PORTAL_HTTPS=1 only if you serve the portal over HTTPS
HTTPS_ONLY = os.environ.get("PORTAL_HTTPS") == "1"

# Lock a username+computer for LOCK_MINUTES after MAX_FAILED wrong logins
MAX_FAILED = 5
LOCK_MINUTES = 5


def get_secret_key():
    """Create a random secret key once and keep it in secret.key."""
    path = os.path.join(DATA_DIR, "secret.key")
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return f.read().strip()
    key = secrets.token_hex(32)
    with open(path, "w", encoding="utf-8") as f:
        f.write(key)
    return key
