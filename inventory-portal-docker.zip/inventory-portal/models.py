"""Database tables and connection helpers."""
import sqlite3

from flask import g
from werkzeug.security import generate_password_hash

import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS departments (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT NOT NULL UNIQUE COLLATE NOCASE,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS users (
    id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name            TEXT NOT NULL,
    username             TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash        TEXT NOT NULL,
    department_id        INTEGER REFERENCES departments(id),
    role                 TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('admin','user')),
    must_change_password INTEGER NOT NULL DEFAULT 1,
    is_active            INTEGER NOT NULL DEFAULT 1,
    created_at           TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS equipment (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_id      INTEGER NOT NULL REFERENCES users(id),
    department_id INTEGER REFERENCES departments(id),
    asset_tag     TEXT,
    name          TEXT,
    type          TEXT,
    brand         TEXT,
    model         TEXT,
    serial_no     TEXT,
    location      TEXT,
    status        TEXT,
    purchase_date TEXT,
    remarks       TEXT,
    updated_at    TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS activity_log (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER,
    username   TEXT,
    action     TEXT NOT NULL,
    details    TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE INDEX IF NOT EXISTS idx_equipment_owner ON equipment(owner_id);
CREATE INDEX IF NOT EXISTS idx_equipment_dept  ON equipment(department_id);
CREATE INDEX IF NOT EXISTS idx_users_dept      ON users(department_id);
"""


def connect():
    """Open a SQLite connection with the safe settings for many users."""
    conn = sqlite3.connect(config.DB_PATH, timeout=5)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")      # readers do not block the writer
    conn.execute("PRAGMA busy_timeout=5000")     # wait up to 5 s if the DB is busy
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def get_db():
    if "db" not in g:
        g.db = connect()
    return g.db


def close_db(_exc=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_app(app):
    app.teardown_appcontext(close_db)


def init_db():
    """Create tables, and create the first admin if there are no users yet."""
    conn = connect()
    try:
        conn.executescript(SCHEMA)
        if conn.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
            row = conn.execute("SELECT id FROM departments WHERE name=?",
                               (config.DEFAULT_DEPARTMENT,)).fetchone()
            if row:
                dept_id = row["id"]
            else:
                dept_id = conn.execute("INSERT INTO departments(name) VALUES (?)",
                                       (config.DEFAULT_DEPARTMENT,)).lastrowid
            conn.execute(
                "INSERT INTO users(full_name, username, password_hash, department_id,"
                " role, must_change_password) VALUES (?,?,?,?, 'admin', 1)",
                (config.DEFAULT_ADMIN_NAME, config.DEFAULT_ADMIN_USERNAME,
                 generate_password_hash(config.DEFAULT_ADMIN_PASSWORD), dept_id))
        conn.commit()
    finally:
        conn.close()


def log(db, action, details=""):
    """Write one line in the activity log (uses the logged-in user)."""
    user = g.get("user")
    db.execute(
        "INSERT INTO activity_log(user_id, username, action, details) VALUES (?,?,?,?)",
        (user["id"] if user else None, user["username"] if user else None, action, details))
