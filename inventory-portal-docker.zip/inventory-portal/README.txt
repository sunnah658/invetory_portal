FOR AN UBUNTU SERVER WITH DOCKER, READ DOCKER.txt FIRST. (This file explains running on Windows without Docker.)

OFFICE INVENTORY PORTAL  -  how to start (Windows)
====================================================

You need: Python 3.10 or newer (tick "Add Python to PATH" when installing).

1. Copy the whole inventory-portal folder to the server PC
   (use a LOCAL disk, for example C:\inventory-portal - not a network share).

2. Double-click  run.bat
   The first time it installs what it needs (internet needed once).
   When you see "Portal is starting on port 8000" it is ready.

3. Open a browser and go to:
      http://localhost:8000                 (on the server PC)
      http://SERVER-IP:8000                 (from other PCs)
   If other PCs cannot open it, allow port 8000 in Windows Firewall:
      Windows Defender Firewall > Advanced settings > Inbound Rules > New Rule
      > Port > TCP 8000 > Allow.

4. First login (admin):
      Username:   admin
      Password:   ChangeMe@123
      Department: All departments (admin only)
   The portal makes you choose a new password immediately.

5. Set up (as admin):
      Departments    -> add your departments
      Users          -> add users one by one, OR
      Import users   -> upload a CSV with all 200 people
                        (sample: static\users_template.csv)
   Each new user gets a temporary password and must change it at first login.

6. Users log in with username + password + their department,
   then use "My equipment" to add, edit, search, download CSV and print.

DAILY BACKUP
------------
Double-click backup.bat. It saves a safe copy of the database in the
backups folder (the newest 30 are kept). To do it automatically:
Task Scheduler > Create Basic Task > Daily > Start a program > backup.bat

KEEP RUNNING AFTER LOGOFF
-------------------------
Run run.bat on a server PC that stays on. For an automatic start at boot,
use Task Scheduler > "At startup" > run.bat.

FILES
-----
app.py              starts the portal
config.py           settings (default admin, session time, lock rules)
models.py           database tables (SQLite, WAL mode)
auth.py             login with department, logout, change password
routes_user.py      my equipment + CSV download
routes_admin.py     users, departments, all equipment, import, activity
import_users.py     CSV user import (also: python import_users.py file.csv)
utils.py            CSV export and form checks
backup.py/.bat      database backup
templates/, static/ pages and style

NOTES
-----
- Forgot the admin password? Stop the portal, delete portal.db ONLY if you
  have no data yet. Otherwise ask another admin to reset it from the Users page.
- Never delete secret.key while users are logged in (they will be logged out).
- To use HTTPS, put the portal behind IIS/nginx with a certificate and set the
  environment variable PORTAL_HTTPS=1.
