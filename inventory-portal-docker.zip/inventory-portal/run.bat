@echo off
cd /d "%~dp0"
title Office inventory portal

if not exist venv\Scripts\python.exe (
    echo Creating Python environment, please wait...
    python -m venv venv
    if errorlevel 1 (
        echo Python was not found. Install Python 3.10 or newer and tick "Add Python to PATH".
        pause
        exit /b 1
    )
)

call venv\Scripts\activate
python -m pip install -q -r requirements.txt
if errorlevel 1 (
    echo Could not install the packages. Check the internet connection and try again.
    pause
    exit /b 1
)

echo.
echo Portal is starting on port 8000.
echo   On this computer:  http://localhost:8000
echo   From other PCs:    http://THIS-SERVER-IP:8000
echo Press Ctrl+C to stop.
echo.
python -m waitress --host=0.0.0.0 --port=8000 --threads=8 app:app
pause
