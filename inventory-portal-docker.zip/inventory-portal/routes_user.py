"""Equipment pages: every user sees and edits their own records."""
from flask import (Blueprint, abort, flash, g, redirect, render_template, request,
                   url_for)

from auth import login_required
from models import get_db, log
from utils import (EQUIPMENT_FIELDS, EQUIPMENT_SELECT, STATUS_CHOICES, TYPE_SUGGESTIONS,
                   csv_response, parse_equipment, search_clause)

bp = Blueprint("user", __name__)


def _back_endpoint():
    """After saving, go back to the page the person came from."""
    if request.values.get("back") == "admin" and g.user["role"] == "admin":
        return "admin.all_equipment"
    return "user.equipment_list"


def _my_rows(q):
    sql, params = search_clause(q)
    return get_db().execute(
        EQUIPMENT_SELECT + " WHERE e.owner_id = ?" + sql +
        " ORDER BY e.updated_at DESC, e.id DESC", [g.user["id"]] + params).fetchall()


def _get_allowed(equipment_id):
    row = get_db().execute("SELECT * FROM equipment WHERE id = ?", (equipment_id,)).fetchone()
    if row is None:
        abort(404)
    if row["owner_id"] != g.user["id"] and g.user["role"] != "admin":
        abort(403)
    return row


def _form(item, title, back):
    return render_template("equipment_form.html", item=item, title=title, back=back,
                           fields=EQUIPMENT_FIELDS, statuses=STATUS_CHOICES,
                           types=TYPE_SUGGESTIONS)


@bp.route("/")
@login_required
def home():
    return redirect(url_for("user.equipment_list"))


@bp.route("/equipment")
@login_required
def equipment_list():
    q = (request.args.get("q") or "").strip()
    return render_template("equipment_list.html", rows=_my_rows(q), q=q,
                           fields=EQUIPMENT_FIELDS)


@bp.route("/equipment/download")
@login_required
def equipment_download():
    q = (request.args.get("q") or "").strip()
    log(get_db(), "download_csv", "own equipment")
    get_db().commit()
    return csv_response(_my_rows(q), "my_inventory_" + g.user["username"])


@bp.route("/equipment/add", methods=["GET", "POST"])
@login_required
def equipment_add():
    back = request.values.get("back", "")
    if request.method == "POST":
        data, error = parse_equipment(request.form)
        if error:
            flash(error, "error")
            return _form(data, "Add equipment", back)
        db = get_db()
        cols = list(data)
        db.execute(
            f"INSERT INTO equipment(owner_id, department_id, {', '.join(cols)}) "
            f"VALUES (?, ?, {', '.join('?' for _ in cols)})",
            [g.user["id"], g.user["department_id"]] + [data[c] for c in cols])
        log(db, "equipment_add", data["name"] or data["asset_tag"] or "")
        db.commit()
        flash("Equipment saved.", "ok")
        return redirect(url_for(_back_endpoint()))
    return _form({}, "Add equipment", back)


@bp.route("/equipment/<int:equipment_id>/edit", methods=["GET", "POST"])
@login_required
def equipment_edit(equipment_id):
    row = _get_allowed(equipment_id)
    back = request.values.get("back", "")
    if request.method == "POST":
        data, error = parse_equipment(request.form)
        if error:
            flash(error, "error")
            return _form(data, "Edit equipment", back)
        db = get_db()
        sets = ", ".join(f"{c} = ?" for c in data)
        db.execute(f"UPDATE equipment SET {sets}, updated_at = datetime('now','localtime') "
                   "WHERE id = ?", list(data.values()) + [equipment_id])
        log(db, "equipment_edit", f"id {equipment_id}")
        db.commit()
        flash("Changes saved.", "ok")
        return redirect(url_for(_back_endpoint()))
    return _form(dict(row), "Edit equipment", back)


@bp.route("/equipment/<int:equipment_id>/delete", methods=["POST"])
@login_required
def equipment_delete(equipment_id):
    _get_allowed(equipment_id)
    db = get_db()
    db.execute("DELETE FROM equipment WHERE id = ?", (equipment_id,))
    log(db, "equipment_delete", f"id {equipment_id}")
    db.commit()
    flash("Equipment deleted.", "ok")
    return redirect(url_for(_back_endpoint()))
