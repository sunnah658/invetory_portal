"""Login (with department), logout and change password."""
import secrets
import time
from functools import wraps

from flask import (Blueprint, abort, flash, g, redirect, render_template, request,
                   session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

import config
from models import get_db, log

bp = Blueprint("auth", __name__)

# username+computer -> [failed_count, locked_until]
_FAILED = {}
GENERIC_ERROR = "Wrong username, password or department."


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if g.user is None:
            return redirect(url_for("auth.login"))
        return view(*args, **kwargs)
    return wrapped


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if g.user is None:
            return redirect(url_for("auth.login"))
        if g.user["role"] != "admin":
            abort(403)
        return view(*args, **kwargs)
    return wrapped


def _locked(key):
    entry = _FAILED.get(key)
    return bool(entry and entry[1] > time.time())


def _fail(key):
    count, _until = _FAILED.get(key, [0, 0])
    count += 1
    until = time.time() + config.LOCK_MINUTES * 60 if count >= config.MAX_FAILED else 0
    _FAILED[key] = [0 if until else count, until]


@bp.route("/login", methods=["GET", "POST"])
def login():
    if g.user is not None:
        return redirect(url_for("user.home"))
    db = get_db()
    departments = db.execute("SELECT id, name FROM departments ORDER BY name").fetchall()

    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        password = request.form.get("password") or ""
        dept = request.form.get("department") or ""
        key = (username.lower(), request.remote_addr)

        if _locked(key):
            flash(f"Too many wrong attempts. Try again in {config.LOCK_MINUTES} minutes.", "error")
            return render_template("login.html", departments=departments, username=username)

        user = db.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        ok = bool(user and user["is_active"] and check_password_hash(user["password_hash"], password))
        if ok and user["role"] != "admin":
            ok = dept.isdigit() and int(dept) == user["department_id"]
        if ok and user["role"] == "admin":
            ok = dept == "all" or dept.isdigit()

        if not ok:
            _fail(key)
            flash(GENERIC_ERROR, "error")
            return render_template("login.html", departments=departments, username=username)

        _FAILED.pop(key, None)
        session.clear()
        session.permanent = True
        session["user_id"] = user["id"]
        session["csrf"] = secrets.token_hex(16)
        g.user = user
        log(db, "login")
        db.commit()
        if user["must_change_password"]:
            return redirect(url_for("auth.change_password"))
        return redirect(url_for("user.home"))

    return render_template("login.html", departments=departments, username="")


@bp.route("/logout", methods=["POST"])
def logout():
    if g.user is not None:
        db = get_db()
        log(db, "logout")
        db.commit()
    session.clear()
    return redirect(url_for("auth.login"))


@bp.route("/change-password", methods=["GET", "POST"])
@login_required
def change_password():
    if request.method == "POST":
        current = request.form.get("current") or ""
        new = request.form.get("new") or ""
        again = request.form.get("again") or ""
        db = get_db()
        if not check_password_hash(g.user["password_hash"], current):
            flash("Your current password is not correct.", "error")
        elif len(new) < 8:
            flash("The new password must have at least 8 characters.", "error")
        elif new != again:
            flash("The two new passwords do not match.", "error")
        elif new == current:
            flash("Choose a password different from the old one.", "error")
        else:
            db.execute("UPDATE users SET password_hash=?, must_change_password=0 WHERE id=?",
                       (generate_password_hash(new), g.user["id"]))
            log(db, "change_password")
            db.commit()
            flash("Password changed.", "ok")
            return redirect(url_for("user.home"))
    return render_template("change_password.html")
